classdef Multiple_Snapshot_ParametricZ < ParametricZ
    %This class implements the ParametricZ functionality for a model of the
    %form
    %Z = A(b)*C
    %where A(b) is KxN, C is NxL, and Z is KxL.
    %This yields M = K*L for the measurements z = vec(Z).
    %Notice that the parameters are the vector b and c = vec(C),
    %which yields Nc = N*L
    
    
    
    properties
        
        %The PLinTrans operator
      %  A;
        
        %The number of snapshots
        L;
        Vtd;
        Nr;
        Up;
        %Size of the operator. Copied from A by constructor
        K;N;
        
        %Useful z values
      %  zij_sumSquared;
      %  zij_sumMi;
      %  zij_sumMj;
    end
    
    
    methods
        
        %% Default constructor
        function obj = Multiple_Snapshot_ParametricZ(L,Vtd,Nr,Up)
            
            %Verify that A is a PLinTrans object
         %   if ~isa(A,'PLinTrans')
         %       error('A must be a PLinTrans object')
         %   end
            
            %Verify that L is scalar
            if numel(L) > 1
                error('L should be scalar')
            end
            
            %Assign
        %    obj.A = A;
            obj.L = L;
            obj.Nr=Nr;
            obj.Vtd=Vtd;
            obj.Up=Up;
            
            obj.N=size(Vtd,1)*Nr;
            %Get sizes
            obj.K=size(Up,1)*Nr;
            % [obj.K,obj.N] = A.getSizes();
            
            
            %Pre-compute
         %   [AiNorms,AnNorms] = obj.A.computeAFrobNorms;
         %   obj.zij_sumMj = obj.L*AiNorms.^2;
         %   obj.zij_sumMi = 0;%repmat(AnNorms.^2,obj.L,1);
         %   obj.zij_sumSquared = sum(obj.zij_sumMj);
        end
        
        
        %% returnSizes
        %Return all problem dimensions
        function [M,Nb,Nc] = returnSizes(obj)
            
            %Obtain sizes
            M = obj.L*obj.K;
            % Nb = obj.A.parameterDimension;
            Nb=size(obj.Up,2);
            Nc = obj.N*obj.L;
            
        end
        
        
        %% computeZ
        %Evalute the model for a given bhat and chat.
        function Z = computeZ(obj,bhat,chat)
            %Set the parameter
                    %obj.A.setParameter(bhat);
            
            %Do the multiplication
                    %Z = vec(obj.A.mult(reshape(chat,obj.N,obj.L)));
            %Z=obj.Up*bhat;
            Z=ifft(bhat)*sqrt(length(bhat));
            Z=bsxfun(@times,obj.Vtd,Z.'); % get Vtd*diag(cfov_est)
            Z=fft(reshape(chat,obj.Nr,obj.N/obj.Nr)*Z)/sqrt(obj.Nr);
            Z=vec(Z);
        end
        
        
        %% pComputation
        %Method computes z(bhat,chat), pvar, and pvarBar based on the
        %P-BiG-AMP derivation given the specified inputs. opt is an object
        %of class PBiGAMPOpt
        function [z,pvarBar,pvar] = pComputation(obj,opt,bhat,nub,chat,nuc)
            
            %Computations depend on uniformVariance flag
            if ~opt.uniformVariance            
                Npil=size(obj.Up,1);
                Nr=obj.Nr;
                Ntl=obj.N/obj.Nr;
                Vtd=obj.Vtd;
                Up=obj.Up;               
                ChVt=reshape(chat,Nr,Ntl)*Vtd;
                Term1=abs(fft(ChVt)).^2/Nr;
                Term1=vec(Term1)*sum(nub)/Npil;
                %Ubhat=Up*bhat;
                Ubhat=ifft(bhat)*sqrt(Npil);
                Svec=reshape(nuc,Nr,Ntl);             
                Svec=mean(Svec);
                Term2=Svec*(abs(bsxfun(@times,Vtd,Ubhat.')).^2);
                Term2=vec(kron(Term2,ones(Nr,1)));
                Term3=Svec*(abs(Vtd).^2);
                Term3=vec(kron(Term3,ones(Nr,1)));
               
                %Compute pvarBar
                pvarBar = Term2 + Term1;
                %Compute pvar
                pvar = pvarBar + Term3;
                %Compute z
                           % z1 = vec(obj.A.mult(chat));
                z=bsxfun(@times,ChVt,Ubhat.'); 
                z=vec(fft(z))/sqrt(Nr);
            else
                
              %  not optimized at all
                %Get M
                M = obj.returnSizes();
                
                %Compute z
                z = obj.computeZ(bhat,chat);
                
                %Reshape C
                chat = reshape(chat,obj.N,obj.L);
                
                %Get sums
                sumZi0 = obj.A.computeFrobSum(chat);
                
                %Compute the sum over Z0j
                sumZ0j = obj.L*obj.A.computeFrobNorm()^2;
                
                %Compute pvarBar
                pvarBar = (nub*sumZi0 + nuc*sumZ0j)/M;
                
                %Compute pvar
                pvar = pvarBar + nub*nuc/M*obj.zij_sumSquared;
                
            end
            
        end
        
        
        %% rqComputation
        
        %Method computes Q and R based on the P-BiG-AMP derivation
        %given the specified inputs. opt is an object of class PBiGAMPOpt
        function [rhat,rvar,qhat,qvar] = rqComputation(...
                obj,opt,bhat,nub,chat,nuc,shat,nus)
            
           
            %First, set parameter
                 [~,Nb,Nc] = obj.returnSizes();
            %Handle uniform variance
            if ~opt.uniformVariance
                
                 Npil=size(obj.Up,1);
                 Nr=obj.Nr;
                 Ntl=obj.N/obj.Nr;
                 Vtd=obj.Vtd;
                 Up=obj.Up;
                 Np=size(Up,1);
                ChVt=reshape(chat,Nr,Ntl)*Vtd;
               % Ubhat=Up*bhat;
                Ubhat=ifft(bhat)*sqrt(Npil);
                SVt=reshape(nus,Nr,Np);             
                Svec=mean(SVt).';
                VMt=bsxfun(@times,Vtd,Ubhat.');
                rvar=(abs(VMt).^2)*Svec;
                rvar=1./(rvar+realmin);
                rvar(rvar > opt.varThresh) = opt.varThresh;
                rvar=vec(kron(rvar,ones(Nr,1)));  
                
                %  
                %Reshape
                chat = reshape(chat,obj.N,obj.L);
                nuc = reshape(nuc,obj.N,obj.L);
                
                %First, get Zi0- go ahead and conjugate transpose
                
                
                %Compute qvar (currently inverted)
                 %  qvar = abs(Zi0).^2*nus;
                FChVt= fft(ChVt)/sqrt(Nr);
                qvar= (abs(FChVt).^2)/Np;
                qvar=ones(Nb,1)*(nus.'*vec(qvar));
                qvar = 1 ./ (qvar + realmin);            
                qvar(qvar > opt.varThresh) = opt.varThresh;
              
                %Reshape s terms
                shat = reshape(shat,obj.K,obj.L);
                nus = reshape(nus,obj.K,obj.L);     
                %Compute rhat single sum term
                SMt=reshape(shat,Nr,Np);
                rhat=vec(ifft(SMt*VMt')*sqrt(Nr));
                % rhat = vec(obj.A.multTr(shat));
               
                %Compute qhat single sum term
               qhat=fft(dot(FChVt,SMt).')/sqrt(Npil);
               % Zi0 = (obj.A.multWithDerivatives(chat))';
               % qhat = Zi0*shat;
               
                %Directly compute rvar (currently inverted)
                % rvar = vec(obj.A.multSqTr(nus));
                % rvar=1./(rvar+realmin);
                % rvar(rvar > opt.varThresh) = opt.varThresh;
                %Revectorize chat
                chat = vec(chat);
                
                %Handle double sum terms
              %  rhat = rhat - chat .* ...
              %      vec(obj.A.computeWeightedSum(nub)'*nus);
                 rhat = rhat - chat .* ...     
                     kron((abs(Vtd).^2)*Svec,ones(Nr,1))*sum(nub)/Np;
                
                
                %qhat double sum term
                Cvec=reshape(nuc,Nr,Ntl);             
                Cvec=mean(Cvec);
                Cvec=Cvec*(abs(Vtd).^2);
                muz=mean(reshape(nus,[Nr,Np])).';
                Cvec=Cvec*muz*(Nr/Np);
                %Zi2 = obj.A.multWithSqrDerivatives(nuc);
                %qhat = qhat - bhat .* vec(Zi2'*vec(nus));
                qhat = qhat - (bhat*Cvec) ;
               
            else
                %not optimized at all
                 obj.A.setParameter(bhat);
            
                %Get sizes
             
            
                %Reshape chat
                chat = reshape(chat,obj.N,obj.L);
                
                %First, get Zi0- go ahead and conjugate transpose
                Zi0 = (obj.A.multWithDerivatives(chat))';
                
                %Compute qhat single sum term
                qhat = Zi0*shat;
                
                %Reshape shat term
                shat = reshape(shat,obj.K,obj.L);
                
                %Compute rhat single sum term
                rhat = vec(obj.A.multTr(shat));
                
                %Get sums
                sumZi0 = obj.A.computeFrobSum(chat);
                
                %Compute the sum over Z0j
                sumZ0j = obj.L*obj.A.computeFrobNorm()^2;
                
                %Compute rvar (currently inverted)
                rvar = nus/Nc*sumZ0j;
                
                %Compute qvar (currently inverted)
                qvar = nus/Nb*sumZi0;
                
                %Revectorize chat
                chat = vec(chat);
                
                %Double sum term
                rhat = rhat - nus*nub*(chat .* obj.zij_sumMi);
                qhat = qhat - nus*nuc*(bhat .* obj.zij_sumMj);
                rvar = 1 ./ (rvar + realmin);
                rvar(rvar > opt.varThresh) = opt.varThresh;
                 qvar = 1 ./ (qvar + realmin);
                %Enforce variance limits    
                 qvar(qvar > opt.varThresh) = opt.varThresh;
            end
            
            %Invert the variance computations
          
            
            %Scale the rhat and qhat terms by the variances and then add in
            %the chat and bhat terms
            rhat = rhat .* rvar;
            rhat = rhat + chat;
            qhat = qhat .* qvar;
            qhat = qhat + bhat;
          
        end
        
    end
    
    
    
end
