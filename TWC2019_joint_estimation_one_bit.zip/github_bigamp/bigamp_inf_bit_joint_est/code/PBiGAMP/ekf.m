function we=ekf(meas,tau,R)
clc;
ret=[];
retf=[];

M=length(meas);
phn=(randn(1,M))*tau;
phnc=cumsum(phn);
M=length(meas);
z=[real(meas);imag(meas)];
xmm=[0;0;0];
Pmm=eye(3); % Pmm=[1,0,0;0,0,0;0,0,0];
F=[1,1,0;0,1,0;0,0,1];
Q=[tau^2,0,0;0,0,0;0,0,0];
R=(R)*eye(2)/2;
for i=1:1:M
    xnm=F*xmm;
    Pnm=F*Pmm*F'+Q;
    yn=z(:,i)-h(xnm);
    Hn=jacn(xnm);
    Sn=(Hn*Pnm*Hn')+R;
    Kn=Pnm*Hn'*inv(Sn);
    xmm=xnm+(Kn*yn);
    Pmm=(eye(3)-(Kn*Hn))*Pnm;
end
we=mod(xmm(2),2*pi);
    if(we>pi)
        we=we-(2*pi)
    end
end
