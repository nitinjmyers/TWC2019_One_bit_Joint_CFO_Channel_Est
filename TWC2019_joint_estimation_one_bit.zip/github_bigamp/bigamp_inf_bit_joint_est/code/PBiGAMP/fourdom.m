function X=fourdom(H,Nsub,Nr,Nt,L)
X=reshape(H,[Nr*Nt,L]);
X=fft(X.',Nsub); % automatically scales by Nsub- normalization across subcarriers done
X=reshape(X.',[Nr,Nt*Nsub]);
end