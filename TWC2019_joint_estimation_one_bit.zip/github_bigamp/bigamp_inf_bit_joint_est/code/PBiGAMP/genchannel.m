function [H,X]=genchannel(Nr,Nt,Nd,Num_cluster,alf_rc,tt)
rng(12*tt);
% Model parameters

% Channel model
srrc = false; % use SRRC instead of RC time-domain pulse?
Npre = min(2,round(Nd/2)); % channel taps before first arrival [dflt=5]
%- depends on alf_rc
Npst = min(2,round(Nd/2)); % channel taps after last arrival [dflt=5]
BNr=dftmtx(Nr)/sqrt(Nr);
BNt=dftmtx(Nt)/sqrt(Nt);
% create aperture/delay channel
H = zeros(Nr,Nt,Nd); % MIMO matrix for each delay
X=zeros(Nr,Nt*Nd);
delay = zeros(Num_cluster,1);
gain = zeros(Num_cluster,1);
theta_t = zeros(Num_cluster,1);
theta_r = zeros(Num_cluster,1);
n = [0:Nd-1];               % baud-normalized sampling times
delcl=[Npre+rand(1,Num_cluster)*(Nd-Npre-Npst),Npre+rand(1)*(Nd-Npre-Npst)]; % 4 clusters
% angle spread 15 degrees 
N_p=Num_cluster;
Atm=(pi*rand(1,N_p))-(pi/2);
Arm=(pi*rand(1,N_p))-(pi/2);
theta_t=[];
theta_r=[];
N_ray=10;
for i=1:1:N_p
     Rt=(2*rand(1,N_ray))-1;  
     Rr=(2*rand(1,N_ray))-1;  
     theta_t=[theta_t,Atm(i)+(pi*exprnd(12,1,N_ray).*Rt/180)];  % ~15 degrees angle spread
     theta_r=[theta_r,Arm(i)+(pi*exprnd(12,1,N_ray).*Rr/180)];
end

for l=1:Num_cluster*N_ray % for each path...
    delay(l) =delcl(floor((l-1)/N_ray)+1)+0.1*rand(1); % delay (between Npre and Nd-Npst)
    if srrc
        pulse = ( (1-alf_rc)*sinc((n-delay(l))*(1-alf_rc)) ...
            + cos(pi*(n-delay(l))*(1+alf_rc))*4*alf_rc/pi ...
            )./(1-(4*alf_rc*(n-delay(l))).^2);
    else % rc pulse
        pulse = cos(pi*alf_rc*(n-delay(l)))./(1-(2*alf_rc*(n-delay(l))).^2) ...
            .*sinc(n-delay(l)); % raised-cosine impulse response
    end
    pulse = pulse/norm(pulse);
    
    gain(l) = randn(1,2)*[1;1i]/sqrt(2*Num_cluster*N_ray); % complex gain
    for d=1:Nd % for each delay ...
        H(:,:,d) =  H(:,:,d) + pulse(d)*gain(l)...
            *exp(1i*pi*sin(theta_r(l))*(0:Nr-1))' ...
            *exp(1i*pi*sin(theta_t(l))*(0:Nt-1));
    end
end

    for d=0:1:Nd-1 % for each delay compute spectrum X in paper
        X(:,(Nt*d)+1:1:Nt*(d+1))=BNr'*H(:,:,d+1)*BNt;
    end
end