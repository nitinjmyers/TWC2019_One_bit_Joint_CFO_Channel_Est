function ret=h(d)
    ret=[d(3)*cos(d(1));d(3)*sin(d(1))];
end