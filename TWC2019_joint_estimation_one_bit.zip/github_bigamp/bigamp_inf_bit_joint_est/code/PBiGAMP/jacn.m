function Hn=jacn(s)
r1=[-s(3)*sin(s(1)),0,cos(s(1))];
r2=[s(3)*cos(s(1)),0,sin(s(1))];
Hn=[r1;r2];
end