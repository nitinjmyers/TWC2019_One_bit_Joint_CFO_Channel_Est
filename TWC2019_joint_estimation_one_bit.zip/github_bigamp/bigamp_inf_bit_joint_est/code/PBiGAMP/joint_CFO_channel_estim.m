clear all;
clc;
addpath('../main');
addpath('../EMGMAMP');
tic;
SNRvec=[0];%[-10:2:0],[5:5:20]];
flcount=zeros(1,length(SNRvec)); % log to check how many times algo. failed to suceed even in MaxTrials
Nrnd=1;
maxTrials = 1;              % for large number of pilots(Nt*L) 1 is sufficient 
EMopt.B_type = 'CBG';       % changed from CG to CBG- b is also sparse
EMopt.C_type = 'CBG';
EMopt.C_var_init = 'fixed'; % fixed or dense?
EMopt.B_var_init = 'fixed';
EMopt.C_learn_var = 1;   
EMopt.B_learn_var = 1;  % can change to 1  
EMopt.C_learn_lambda = 1; % to learn sparsity or not - binary variable   
EMopt.B_learn_lambda = 1;      
EMopt.maxEMiter = 10;
EMopt.learn_noisevar=0;

%system initialization
Nr=32;                   %Rx antennas
Nt=32;                   % TX antennas
Ld=16;                   %number of taps in the wideband channel
Np=1024;                 %number of pilots
Spup=0;                 %(Np>=(Nt*Ld)); %to speedup or not with Jianhua's time domain shifted Zadoff-Chu training
for ttype=2:1:2
Trn_type=ttype;                 % 1-QPSK, 2- iid gaussian
we=2*pi*22.5/1024;              % maximally off grid CFO for Np=1024, defined in paper 
                                % this corresponds to 58ppm at fc=38GHz,
                                % BW=100MHz
cfomax=10*0.05;                 
bndlim=Np/8;                    % Used in PBiGAMP, Exploits the fact that CFO is bounded in practice, Chose 1/8 of BW to account for leakage effects
cfop=exp(1i*(we*[0:1:Np-1])).'; % Phase error vector due to CFO only, add phase noise before corrupting measurements
Ur=dftmtx(Nr)/sqrt(Nr);         % To model  channel sparsity
Ut=dftmtx(Nt)/sqrt(Nt);         % To model  channel sparsity
Up=dftmtx(Np)'/sqrt(Np);        % To exploit sparsity of phase error vector

%% Parameters for channel model- check genchannel function
Num_cluster=4;                  
alf_rc=0;
sleak=15;                
rng(21);
    if(Spup==1) %Time domain shifted Zadoff chu training defined in Jianhua's TSP paper, This will speedup BIGAMP, but results in an identifiability issue
                % See CFO propagation effect section in our joint estimation paper
       Tg=exp(1i*1*pi*([0:1:Np-1].^2)/Np);              
        Trn=zeros(Nt,Np);
        for k=1:1:Nt
            Trn(k,:)=circshift(Tg,[0,(k-1)*Ld]);
        end
    else
        switch(Trn_type)
            case 1
            Trn=exp(1i*pi*randi(4,[Nt,Np])/2)*exp(1i*pi/4);             % IID QPSK training
            case 2
            Trn=(randn(Nt,Np)+1i*randn(Nt,Np))/sqrt(2);                 % IID Gaussian training 
        end
    end
              
for tt=1:1:Nrnd
    rng(12*(tt));
    [CH,Xo]=genchannel(Nr,Nt,Ld,Num_cluster,alf_rc,tt);  % CH is channel tensor- NrxNtxNd- wideband 
    Xo=reshape(Xo,[Nr,Nt*Ld]);
    pnvec=0.067*randn(Np,1);                             % Gaussian random variables for phase noise process
    cfov=cfop.*exp(1i*cumsum(pnvec));                    % phase error process - CFO +phase noise
    
    noisevec=complex(randn(Nr*Np,1),randn(Nr*Np,1));     % Generate AWGN samples
    Ttd=[];
    for i=0:1:Ld-1
            Ttd=[Ttd;circshift(Trn,[0,i])];              % Criculant shift training block (training with cyclic prefix)
    end
    Vtd=kron(eye(Ld),Ut')*Ttd;                           % This is the F defined in our TWC paper eq. (6)

    z=vec((Ur*Xo*Vtd*diag(cfov)));                       % This is the z defined in eq. (8)
    optIn.uniformVariance = 0;                           % non-uniform variance PBiGAMP

    %% Problem setup
    Nb = Np;                                             % size of phase error vector
    Nc = Nr*Nt*Ld;                                       % length of channel vector NrXNtXLd
    M = Np*Nr; %number of measurements   

    L = 1;  % number of snapshots  - changed the structure of problem- Z^T.Ur^*=diag(Hb)*AC, where A=Vtd.', C=X.'
    %% Build the Z object for PBiGAMP
    zObject = Multiple_Snapshot_ParametricZ(L,Vtd,Nr,Up);  % All optimizations in the Appendix of our TWC paper are done inside this function
    problem = PBiGAMPProblem();
    problem.M = M;
    problem.Nb = Nb;
    problem.Nc = Nc;
    problem.zObject = zObject;
    c=vec(Xo);                                              % c is the vectorized sparse representation of the wideband channel (see our TWC paper)
    opt = PBiGAMPOpt();
    opt.uniformVariance = optIn.uniformVariance;
    opt.verbose = 0;
    %% Continue setup
    CFO_SNR=zeros(Np,length(SNRvec));                       % Place holder to store phase error vector obtained with PBiGAMP. EKF is used over this vector to estimate CFO
    CFO_var=CFO_SNR;                                       
    cguess=(randn(Nc,1)+1i*randn(Nc,1))/sqrt(2);            % Start with a random guess for the sparse channel vector
    bhat =1*(randn(Nb,1)+1i*randn(Nb,1))/sqrt(2);           % Start with a random guess for the DFT( phase error vector) 
    bguess=bhat.*[ones(bndlim,1);0.01*ones(Nb-(2*bndlim),1);ones(bndlim,1)];        % This is a more reasonable guess as DFT(phase error vector) is concentrated due to bounded CFO
    for ss=1:1:length(SNRvec)
        SNR=SNRvec(ss);
        nuw=norm(Trn,'fro').^2;                             
        nuw=nuw/(Np*(10^(SNR/10)));                         % Noise variance
        y = z + sqrt(nuw/2)*noisevec;
        SNR_linear=norm(z,'fro')^2/(M*nuw);
        opt.tol = max(min(1e-3, 1/SNR_linear),1e-15);       % To reduce stochastic resonance effect
        threshNMSE=20*log10(1*sqrt(nuw*length(z))/norm(y,'fro')); 

        %Specify error functions
        opt.error_functionB = @(qval) 0;
        opt.error_functionC = @(qval) 0;
        opt.error_function = @(qval) 20*log10(norm(qval - y,'fro') / norm(y,'fro'));  %   

        %% Try EM-P-BiG-AMP
        cold=zeros(Nc,1);
        bold=zeros(Nb,1);
        olderr=100;
        %EMBiGAMP
            %Specify options
            EMopt.B_var=1;
            EMopt.C_var=1;       % Determine from several realizations of Xo
                                  %1/(Ld*0.75*C_lambdaest)
                                     %var(b)*var(c) matters
            EMopt.B_lambda = ([ones(bndlim,1);zeros(Np-(2*bndlim),1);ones(bndlim,1)]*1);  %added this-sparsity fraction
            EMopt.C_lambda = 0.01;                                                          %start smaller
            EMopt.noise_var=nuw;
            opt.nit = 75;                                                                   % iterations for pbigamp
            opt.step=0.05; 
            %Count failures
            failCounter = 0;
            stop = false;
  
            while ~stop
                %Run EM-P-BiG-AMP
                [estFinEM, ~, ~,estHistEM] = ...
                    EMPBiGAMP(y,problem,opt,EMopt,bndlim,tt+failCounter,cguess,bguess);
                if(estHistEM.errZ(end)<olderr)  
                        olderr=estHistEM.errZ(end);
                        cold=estFinEM.chat;
                        bold=estFinEM.bhat;
                        bestvar=estFinEM.bvar;
                end
                if ((estHistEM.errZ(end) < threshNMSE) || failCounter ==0)
                    stop = true;
                else
                    [~,ind]=sort(abs(cold));
                    cguess=cold;
                    cguess(ind(1:1:Nc-400))=0;
                    failCounter = failCounter + ~(failCounter == maxTrials);           
                end
            end
        flcount(ss)=flcount(ss)+(failCounter == maxTrials);  
        cest=cold;
        sc=cest'*c/(norm(cest,'fro')^2);
        Xest=reshape(sc*cest,[Nr,Nt*Ld]);
        MSE=(norm(Xo-Xest,'fro')^2);   
        NMSE(ss)=(MSE/(norm(Xo,'fro')^2));               % NMSE of the channel estimate
        CFO_SNR(:,ss)=bold;                              % Estimated phase error vector
        CFO_var(:,ss)=bestvar;    
    end
NMSE_dB=10*log10(NMSE)
end
end
toc
CHest=reshape(cest,[32,32,16]);
figure(1)
surf(abs((reshape(sum(CHest,3),[32,32]))))              % sum gives us DC subcarrier channel
title('Estimated angle domain channel (DC subcarrier)')
xlabel('AoA bin index')
ylabel('AoD bin index')
view([0,90])
figure(2)
surf(abs(Ur'*(reshape(sum(CH,3),[32,32]))*Ut))
title('Original angle domain channel (DC subcarrier)')
xlabel('AoA bin index')
ylabel('AoD bin index')
view([0,90])

figure(3)
xindx=[0:1:Np-1]/Np;  
xindx(xindx>0.5)=xindx(xindx>0.5)-1;
xindx=fftshift(xindx);  
% xindx is proportional to \Delta f/BW
BW=100e6;
fc=38e9;
cfoppmindx=BW*xindx*1e6/fc;    % measure how much in ppms
Spec=fftshift(abs(CFO_SNR));
plot(cfoppmindx,Spec,'k-')
hold on;
ylabel('Magnitude of DFT( estim. phase error vec)')   % try setting phase noise to 0 to check if we get perfect spectrum (off-grid case)
xlabel('CFO(ppm)')
xlim([-100,100])