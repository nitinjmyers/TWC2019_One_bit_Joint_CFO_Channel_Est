clear all;
clc;
Nr=16;                   %Rx antennas
Nt=16;
Ld=4;                   %number of channel matrix taps
Np=64;             %number of pilots

fcfo=0.05;%60*20e-6; % in GHz (60GHz*20ppm)
W=2; %bandwidth 2GHz
we=2*pi*fcfo/W;              % check Nb accordingly
clis=[];
pn_sig=0;  % tauvec(ss);
Niter=1000;
for ii=1:1:Niter
    
pnv=zeros(1,Np);
pnv(1)=pn_sig*rand;
for i=2:1:Np
pnv(i)=pnv(i-1)+ pn_sig*rand;
end
cfov=(exp(1i*(we*[0:1:Np-1])).*exp(1i*pnv)).';
b=fft(cfov);
Num_cluster=4;
alf_rc=0.8;
sleak=15;                %helps for pbigamp only - considers leakage effect in 3 dimensions- AoA, AoD, time - Sparsity = sleak*Num_cluster
[CH,Xo]=genchannel(Nr,Nt,Ld,Num_cluster,alf_rc);  % CH is channel tensor- NrxNtxNd
c=vec(Xo.');
clis=[clis,c];
end