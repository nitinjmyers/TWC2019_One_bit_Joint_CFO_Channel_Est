function Srate=ratecompute(G,Gest,SNR,Nsub,Nr,Nt,Ld)
Srate=0;  
F=fourdom(G,Nsub,Nr,Nt,Ld); % subcarrier domain MIMO
Fest=fourdom(Gest,Nsub,Nr,Nt,Ld);
for jj=1:1:Nsub
    H=F(:,1+((jj-1)*Nt):jj*Nt);
    Hest=Fest(:,1+((jj-1)*Nt):jj*Nt);
    [Uest,Sest,Vest]=svd(Hest);
    npow=diag(Sest).*diag(Sest);
    npow=1./npow;
    scl=10^(-SNR/10);
    npow=npow*scl;
    Pt=1;%10^(SNR/10);
    palloc=wfill(npow.',Pt);
    
    Nr=size(H,1);
    
    EfNsC=(scl*eye(Nr));

    Pmat=Uest'*H*Vest;
    rk=size(Uest,2);
    Rate=0;
    for i=1:1:rk
     pow= (abs(Pmat(i,:)).^2);
     pow=pow.*palloc;
     cursnr=pow(i)/(scl+sum(pow)-pow(i));
     Rate=Rate+log2(1+cursnr);
    end
    Srate=Srate+Rate;
end
Srate=Srate/Nsub;
end

