clear all;
clc;
SNRvec=[0];
subvec=2.^[0:2:12];
a=zeros(length(subvec),length(SNRvec));
rng(12);
Nr=1;
Nt=1;
L=8;

H=[1,-1,2,3,4,-1,0,0];
ns=(randn(Nr,Nt*L)+1i*randn(Nr,Nt*L));
for ii=1:1:length(subvec)
    for jj=1:1:length(SNRvec)
    Hest=H+((10^(-SNRvec(jj)/20))*ns);
    a(ii,jj)=ratecompute(H,Hest,SNRvec(jj),subvec(ii),Nr,Nt,L);
    end
end