%Simple vectorization operation
function res = vec(q)
res = q(:);

