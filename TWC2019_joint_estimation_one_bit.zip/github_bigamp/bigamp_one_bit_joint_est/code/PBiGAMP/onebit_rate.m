function Srate=onebit_rate(G,Gest,SNR,Nsub,Nr,Nt,Ld)
Srate=0;  
et=0.3634;
corr=(1-et)^2;
F=fourdom(G,Nsub,Nr,Nt,Ld); % subcarrier domain MIMO
Fest=fourdom(Gest,Nsub,Nr,Nt,Ld);
rk=min(Nr,Nt);
Allocmat=zeros(Nsub,rk);
scl=10^(-SNR/10);
qnoise=0;
Pmat=zeros(rk,rk,Nsub);
for jj=1:1:Nsub
    H=F(:,1+((jj-1)*Nt):jj*Nt);
    Hest=Fest(:,1+((jj-1)*Nt):jj*Nt);
    [Uest,Sest,Vest]=svd(Hest);
    Uest=Uest(:,1:1:rk);
    Vest=Vest(:,1:1:rk);    
    Pmat(:,:,jj)=Uest'*H*Vest;
    npow=diag(Sest).*diag(Sest);
    npow=1./npow;
    npow=npow*scl;
    Pt=1;%10^(SNR/10);
    palloc=wfill(npow.',Pt);
    Allocmat(jj,:)=palloc;
    qnoise=qnoise+(H*Vest*diag(palloc)*Vest'*H');
end

Nr=size(H,1);
EfNsC=(scl*eye(Nr));
qnoise=et*diag(diag(qnoise)/Nsub);
EfNsC=(1-et)*(EfNsC+qnoise);

for jj=1:1:Nsub
    Rate=0;
    for i=1:1:rk
     pow= (abs(Pmat(i,:,jj)).^2);
     pow=pow.*Allocmat(jj,:);
     Intf=corr*(sum(pow)-pow(i));
     noiseterm=abs(Uest(:,i)'*EfNsC*Uest(:,i));
     cursnr=corr*pow(i)/(noiseterm+Intf);
     Rate=Rate+log2(1+cursnr);
    end
    Srate=Srate+Rate;
end
Srate=Srate/Nsub;
end